package Automation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class Assertions {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\prateekm\\Downloads\\chromedriver.exe");
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		Thread.sleep(1000);
		for(int i=1;i<=2;i++)
		{
		driver.findElement(By.xpath("//input[@value='option1']")).click();	
		System.out.println(driver.findElement(By.xpath("//input[@value='option1']")).isSelected());
		//Assert.assertTrue(driver.findElement(By.xpath("//input[@value='option1']")).isSelected());
	}
		System.out.println(driver.findElements(By.xpath("//input[@type='checkbox']")).size());

}
}
