package Automation;
//
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class CheckBoxes {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\prateekm\\Downloads\\chromedriver.exe");
		driver.get("https://www.rahulshettyacademy.com/dropdownsPractise/");
		Thread.sleep(1000);
		driver.findElement(By.id("ctl00_mainContent_chk_IndArm")).click();
		//System.out.println(driver.findElement(By.id("ctl00_mainContent_chk_IndArm")).isSelected()); //method to find if checkbox is selected or not---return boolean value--True/False
		//Assertions
Assert.assertTrue(driver.findElement(By.id("ctl00_mainContent_chk_IndArm")).isSelected());
		//System.out.println(driver.findElements(By.xpath("//input[@type='checkbox']")).size());
	
	}

}
