package Automation;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class CompXMedi {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\prateekm\\Downloads\\chromedriver.exe");
		driver.get("https://cx4000.compxmedical.com:8043/Account/Login?ReturnUrl=%2f");
		Thread.sleep(1000);
		driver.findElement(By.id("details-button")).click();
		driver.findElement(By.linkText("Proceed to cx4000.compxmedical.com (unsafe)")).click();
		driver.manage().window().maximize();
		Thread.sleep(2000);
		// Entering valid credentials in Email & Password field
		driver.findElement(By.xpath("//input[@id='Email']")).sendKeys("omveers@chetu.com");
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("Chetu@123");
		// Clicking on LogIn Button
		driver.findElement(By.xpath("//input[@value='Log in']")).click();
		// Assertion of cuurent URL
		String CurrentUrl = driver.getCurrentUrl();
		if (CurrentUrl == "https://cx4000.compxmedical.com:8043/Scheduling/Scheduling/Dashboard") {
			Assert.assertTrue(true);
			// System.out.println("User has logged in Successfully");
		}
		driver.findElement(By.xpath("//ul[@class='nav-list']/li[@id='Scheduling']/a")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[contains(text(),'Add New Order')]")).click();
		driver.findElement(By.id("lnk_Transportation")).click();
		String TransportUrl = driver.getCurrentUrl();
		if (TransportUrl == "https://cx4000.compxmedical.com:8043/Scheduling/Scheduling/Transportation") {
			Assert.assertTrue(true);
			// System.out.println("User has Navigated to Transport scheduling screen
			// Successfully");
		}
		driver.findElement(By.id("txtClaimant")).sendKeys("kar");
		Thread.sleep(1000);
		List<WebElement> options = driver.findElements(By.xpath("//li[@role='option']"));
		for (WebElement option : options) {
			if (option.getText().equalsIgnoreCase("CARGILL, KARLENE - IM0176116 (COMPX179)")) {
				option.click();
			}
		}
		Thread.sleep(2000);
		String UserName = driver
				.findElement(
						By.xpath("//div[@class='col-md-8 col-xs-8 m-5-0 ']/span[contains(text(),'CARGILL, KARLENE')]"))
				.getText();
		Assert.assertEquals(UserName, "CARGILL, KARLENE");

		driver.findElement(By.xpath("//span[@class='k-input']")).click();
	
		driver.findElement(By.xpath("(//li[text()='Patient'])[1]")).click();
		Thread.sleep(2000);
	}
}
